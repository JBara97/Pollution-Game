OLD : a + b are each 100 runs

c + e is 100 runs each and contains the correct code but still 0 mutation
Mutation: d + f is 100 runs and contains the correct code and has 0.01 mutation