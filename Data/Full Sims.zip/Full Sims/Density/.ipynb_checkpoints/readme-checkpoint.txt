60% defectors initially
mutation 0.01

N=50 is a copy of the final T+1'th entries in c