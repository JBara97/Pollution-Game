60% defectors initially
mutation 0.01
T = 201 timesteps

Each csv is a (Runs, len(M)) sized csv where Runs is the number of runs and M is the set of migratory distances
cr - cleaning rate C/N
pcp - per-capita pollution
pce - per-capita expense
