a + b are each 100 runs

c is 100 runs and contains the correct code but still 0 mutation
d is 100 runs and contains the correct code and has 0.01 mutation