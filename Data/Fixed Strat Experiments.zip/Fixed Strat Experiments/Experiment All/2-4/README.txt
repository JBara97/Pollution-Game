Combined data from experiments 2-4

Runs = 50
L = 50
N = 50
R = 5
T = 201

M = [2,5,10]
D = [10,20,30,40]
Phi = [0.5,1,2,3,4,5]
